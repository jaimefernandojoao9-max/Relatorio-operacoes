// server.js
// Sistema de Relatorio de Operacoes — versao para hospedagem na nuvem.
// Tudo num so ficheiro de proposito, para ser facil de enviar para o
// GitHub a partir do telemovel (sem precisar de pastas dentro de pastas).

require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

// ---------------------------------------------------------------------
// Configuracao obrigatoria
// ---------------------------------------------------------------------
if (!process.env.DATABASE_URL) {
  console.error('ERRO: falta a variavel DATABASE_URL (a ligacao a base de dados).');
  process.exit(1);
}
if (!process.env.JWT_SECRET) {
  console.error('ERRO: falta a variavel JWT_SECRET (segredo para os logins).');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false }
});

// ---------------------------------------------------------------------
// Base de dados: cria as tabelas se ainda nao existirem
// ---------------------------------------------------------------------
async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'operador' CHECK (role IN ('admin','operador')),
      active BOOLEAN NOT NULL DEFAULT true,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS reports (
      id SERIAL PRIMARY KEY,
      protocolo TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL,
      mes TEXT,
      ano TEXT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      status TEXT NOT NULL DEFAULT 'enviado',
      total_diario NUMERIC NOT NULL DEFAULT 0,
      saida NUMERIC NOT NULL DEFAULT 0,
      restante NUMERIC NOT NULL DEFAULT 0,
      reprografia NUMERIC NOT NULL DEFAULT 0,
      banca NUMERIC NOT NULL DEFAULT 0,
      observacoes TEXT,
      relator TEXT,
      responsavel TEXT,
      relator_assinado BOOLEAN NOT NULL DEFAULT false,
      responsavel_assinado BOOLEAN NOT NULL DEFAULT false,
      created_at BIGINT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS report_items (
      id SERIAL PRIMARY KEY,
      report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
      descricao TEXT,
      valor_unit NUMERIC NOT NULL DEFAULT 0,
      qtd NUMERIC NOT NULL DEFAULT 0,
      valor NUMERIC NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS report_materials (
      id SERIAL PRIMARY KEY,
      report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
      data_hora TEXT,
      material TEXT,
      qtd NUMERIC NOT NULL DEFAULT 0,
      recebido_por TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_reports_user ON reports(user_id);
    CREATE INDEX IF NOT EXISTS idx_items_report ON report_items(report_id);
    CREATE INDEX IF NOT EXISTS idx_materials_report ON report_materials(report_id);
  `);
}

function num(v) {
  const n = parseFloat(String(v == null ? 0 : v).toString().replace(',', '.'));
  return Number.isNaN(n) ? 0 : n;
}

// ---------------------------------------------------------------------
// Autenticacao
// ---------------------------------------------------------------------
function signToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, name: user.name, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '12h' }
  );
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const parts = header.split(' ');
  const token = parts.length === 2 && parts[0] === 'Bearer' ? parts[1] : null;
  if (!token) return res.status(401).json({ error: 'Sessao invalida. Faca login novamente.' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub, username: payload.username, name: payload.name, role: payload.role };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Sessao expirada. Faca login novamente.' });
  }
}

// ---------------------------------------------------------------------
// App
// ---------------------------------------------------------------------
const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

app.get('/api/health', (req, res) => res.json({ ok: true }));

// diz ao frontend se ainda nao existe nenhum utilizador (primeiro arranque)
app.get('/api/auth/needs-setup', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT COUNT(*)::int AS total FROM users');
    res.json({ needsSetup: r.rows[0].total === 0 });
  } catch (err) { next(err); }
});

// cria o primeiro utilizador (administrador) -- so funciona se ainda nao houver nenhum
app.post('/api/auth/setup', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT COUNT(*)::int AS total FROM users');
    if (r.rows[0].total > 0) {
      return res.status(403).json({ error: 'Ja existe pelo menos um utilizador. Usa o login normal.' });
    }
    const { name, username, password } = req.body || {};
    if (!name || !username || !password) {
      return res.status(400).json({ error: 'Preenche nome, utilizador e senha.' });
    }
    if (String(password).length < 6) {
      return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres.' });
    }
    const passwordHash = bcrypt.hashSync(String(password), 10);
    const insert = await pool.query(
      `INSERT INTO users (name, username, password_hash, role, active)
       VALUES ($1, $2, $3, 'admin', true) RETURNING id, name, username, role`,
      [String(name).trim(), String(username).trim(), passwordHash]
    );
    const user = insert.rows[0];
    res.status(201).json({ token: signToken(user), user });
  } catch (err) {
    if (err && err.code === '23505') return res.status(409).json({ error: 'Esse nome de utilizador ja existe.' });
    next(err);
  }
});

app.post('/api/auth/login', async (req, res, next) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) return res.status(400).json({ error: 'Preencha utilizador e senha.' });

    const r = await pool.query('SELECT * FROM users WHERE username = $1 AND active = true', [String(username).trim()]);
    const user = r.rows[0];
    if (!user || !bcrypt.compareSync(String(password), user.password_hash)) {
      return res.status(401).json({ error: 'Utilizador ou senha incorretos.' });
    }
    res.json({ token: signToken(user), user: { id: user.id, name: user.name, username: user.username, role: user.role } });
  } catch (err) { next(err); }
});

app.get('/api/auth/me', requireAuth, async (req, res, next) => {
  try {
    const r = await pool.query('SELECT id, name, username, role, active FROM users WHERE id = $1', [req.user.id]);
    const user = r.rows[0];
    if (!user || !user.active) return res.status(401).json({ error: 'Sessao invalida.' });
    res.json({ user });
  } catch (err) { next(err); }
});

// permite a um admin criar utilizadores adicionais (operadores), ja dentro do sistema
app.post('/api/users', requireAuth, async (req, res, next) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Sem permissao.' });
    const { name, username, password, role } = req.body || {};
    if (!name || !username || !password) return res.status(400).json({ error: 'Preenche nome, utilizador e senha.' });
    if (String(password).length < 6) return res.status(400).json({ error: 'A senha deve ter pelo menos 6 caracteres.' });
    const passwordHash = bcrypt.hashSync(String(password), 10);
    const finalRole = role === 'admin' ? 'admin' : 'operador';
    const insert = await pool.query(
      `INSERT INTO users (name, username, password_hash, role, active)
       VALUES ($1, $2, $3, $4, true) RETURNING id, name, username, role`,
      [String(name).trim(), String(username).trim(), passwordHash, finalRole]
    );
    res.status(201).json({ user: insert.rows[0] });
  } catch (err) {
    if (err && err.code === '23505') return res.status(409).json({ error: 'Esse nome de utilizador ja existe.' });
    next(err);
  }
});

function gerarProtocolo() {
  const d = new Date();
  const p = (n) => (n < 10 ? '0' + n : '' + n);
  return 'OP-' + String(d.getFullYear()).slice(2) + p(d.getMonth() + 1) + p(d.getDate()) + '-' + Math.floor(1000 + Math.random() * 9000);
}

function montarRelatorio(row) {
  return {
    id: row.id,
    protocolo: row.protocolo,
    date: row.date,
    mes: row.mes,
    ano: row.ano,
    status: row.status,
    totals: {
      totalDiario: Number(row.total_diario),
      saida: Number(row.saida),
      restante: Number(row.restante),
      reprografia: Number(row.reprografia),
      banca: Number(row.banca)
    },
    items: (row.items || []).filter((it) => it && it.desc != null),
    materials: (row.materials || []).filter((m) => m && m.material != null),
    observacoes: row.observacoes || '',
    relator: row.relator || '',
    responsavel: row.responsavel || '',
    relatorAssinado: !!row.relator_assinado,
    responsavelAssinado: !!row.responsavel_assinado,
    createdAt: Number(row.created_at),
    userId: row.user_id,
    userName: row.user_name
  };
}

const SELECT_REPORT_BASE = `
  SELECT reports.*, users.name AS user_name,
    COALESCE(items.items, '[]'::json) AS items,
    COALESCE(materials.materials, '[]'::json) AS materials
  FROM reports
  JOIN users ON users.id = reports.user_id
  LEFT JOIN (
    SELECT report_id, json_agg(json_build_object('desc', descricao, 'valorUnit', valor_unit, 'qtd', qtd, 'valor', valor) ORDER BY id) AS items
    FROM report_items GROUP BY report_id
  ) items ON items.report_id = reports.id
  LEFT JOIN (
    SELECT report_id, json_agg(json_build_object('dataHora', data_hora, 'material', material, 'qtd', qtd, 'recebidoPor', recebido_por) ORDER BY id) AS materials
    FROM report_materials GROUP BY report_id
  ) materials ON materials.report_id = reports.id
`;

app.post('/api/reports', requireAuth, async (req, res, next) => {
  const client = await pool.connect();
  try {
    const body = req.body || {};
    const relator = String(body.relator || '').trim();
    if (!relator) return res.status(400).json({ error: 'O nome do relator e obrigatorio.' });
    if (!body.relatorAssinado) return res.status(400).json({ error: 'A confirmacao de assinatura do relator e obrigatoria.' });
    if (!body.date) return res.status(400).json({ error: 'A data e obrigatoria.' });

    const total = num(body.totals && body.totals.totalDiario);
    const saida = num(body.totals && body.totals.saida);
    const reprografia = num(body.totals && body.totals.reprografia);
    const banca = num(body.totals && body.totals.banca);
    const items = Array.isArray(body.items) ? body.items : [];
    const materials = Array.isArray(body.materials) ? body.materials : [];
    const createdAt = Date.now();

    await client.query('BEGIN');

    let reportId = null;
    for (let tentativa = 0; tentativa < 20 && !reportId; tentativa++) {
      const protocolo = gerarProtocolo();
      try {
        const insert = await client.query(
          `INSERT INTO reports
           (protocolo, date, mes, ano, user_id, status, total_diario, saida, restante, reprografia, banca,
            observacoes, relator, responsavel, relator_assinado, responsavel_assinado, created_at)
           VALUES ($1,$2,$3,$4,$5,'enviado',$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
           RETURNING id, protocolo`,
          [protocolo, body.date, body.mes || '', body.ano || '', req.user.id, total, saida, total - saida,
            reprografia, banca, body.observacoes || '', relator, String(body.responsavel || '').trim(),
            !!body.relatorAssinado, !!body.responsavelAssinado, createdAt]
        );
        reportId = insert.rows[0].id;
      } catch (err) {
        if (err && err.code === '23505') continue; // protocolo colidiu, tenta outro
        throw err;
      }
    }
    if (!reportId) throw new Error('Nao foi possivel gerar um protocolo unico.');

    for (const it of items) {
      const desc = String((it && it.desc) || '').trim();
      const qtd = num(it && it.qtd);
      const valorUnit = num(it && it.valorUnit);
      if (!desc && !qtd && !valorUnit) continue;
      await client.query(
        'INSERT INTO report_items (report_id, descricao, valor_unit, qtd, valor) VALUES ($1,$2,$3,$4,$5)',
        [reportId, desc, valorUnit, qtd, valorUnit * qtd]
      );
    }
    for (const m of materials) {
      const material = String((m && m.material) || '').trim();
      const dataHora = String((m && m.dataHora) || '').trim();
      const recebidoPor = String((m && m.recebidoPor) || '').trim();
      const qtd = num(m && m.qtd);
      if (!material && !dataHora && !recebidoPor && !qtd) continue;
      await client.query(
        'INSERT INTO report_materials (report_id, data_hora, material, qtd, recebido_por) VALUES ($1,$2,$3,$4,$5)',
        [reportId, dataHora, material, qtd, recebidoPor]
      );
    }

    await client.query('COMMIT');

    const full = await pool.query(SELECT_REPORT_BASE + ' WHERE reports.id = $1', [reportId]);
    res.status(201).json(montarRelatorio(full.rows[0]));
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Nao foi possivel guardar o relatorio no servidor.' });
  } finally {
    client.release();
  }
});

app.get('/api/reports', requireAuth, async (req, res, next) => {
  try {
    const { date, status, q } = req.query;
    let sql = SELECT_REPORT_BASE + ' WHERE 1=1';
    const params = [];

    if (req.user.role !== 'admin') { params.push(req.user.id); sql += ` AND reports.user_id = $${params.length}`; }
    if (date) { params.push(date); sql += ` AND reports.date = $${params.length}`; }
    if (status) { params.push(status); sql += ` AND reports.status = $${params.length}`; }
    if (q) { params.push('%' + q + '%'); sql += ` AND (reports.protocolo ILIKE $${params.length} OR reports.relator ILIKE $${params.length})`; }

    sql += ' ORDER BY reports.created_at DESC';
    const r = await pool.query(sql, params);
    res.json(r.rows.map(montarRelatorio));
  } catch (err) { next(err); }
});

app.get('/api/reports/:id', requireAuth, async (req, res, next) => {
  try {
    const r = await pool.query(SELECT_REPORT_BASE + ' WHERE reports.id = $1', [req.params.id]);
    const row = r.rows[0];
    if (!row) return res.status(404).json({ error: 'Relatorio nao encontrado.' });
    if (req.user.role !== 'admin' && row.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Sem permissao para ver este relatorio.' });
    }
    res.json(montarRelatorio(row));
  } catch (err) { next(err); }
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Rota da API nao encontrada.' }));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Erro interno do servidor.' });
});

const PORT = process.env.PORT || 3000;
initDb()
  .then(() => {
    app.listen(PORT, () => console.log(`Servidor a correr na porta ${PORT}`));
  })
  .catch((err) => {
    console.error('Nao foi possivel preparar a base de dados:', err);
    process.exit(1);
  });
